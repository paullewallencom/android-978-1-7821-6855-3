Download the last version of QCAR SDK and copy it here.
structure will be
ThirdParty\
	vuforia-sdk-android-VERSION\
		assets\
		build\
			include\
			java\
				QCAR\
					QCAR.lib
			lib\